#一个不算太糟糕的项目
#
#2022.5 数据库课程设计作业 
#
#开发
#
#中国石油大学华东
#
#计算机科学与技术学院
#
#计算2003章震豪
#
#tips：我是真不喜欢写前端
#
#前端html+css
#
#tips：想用php，但是没用
#
#tips：想用bookstrap，但是懒
#
#后端ngjnx+docker（虽然我感觉不算用了）+django+mysql
#
#系统Ubuntu 20.04
#
#服务器tencent
#
[快速访问](ppzrfp.club:8888/zhuye)

